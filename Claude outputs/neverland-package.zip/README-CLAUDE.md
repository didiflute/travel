# Wendy’s Neverland — 完整发布包

导出日期：2026-10-17。对应当前已发布版本 9c89b0cb996ee5ea0f41d5526de14c9dea5048e1。

## 给 Claude 的任务

请直接部署这个现成网站，保留现有视觉、交互和文件内容。不要重新生成页面、改成截图、重构为另一套框架或替换 Three.js 版本。先读本文件；把 dist 作为静态网站发布目录，构建命令留空。发布完成后提供可访问的网址，并核对六座城市、地图编辑、列车、昼夜季节和手机布局。

## 目录与运行

- dist/：完整网站，同时也是可编辑源码；包含 HTML、CSS、原生 ES modules、Three.js 与 addons、本地模型和纹理。
- serve.mjs：零 npm 依赖的本地预览服务器。在包根目录执行 `node serve.mjs`，打开 http://127.0.0.1:4173/。
- CITY-DECISIONS.md / DESIGN.md：设计与历次修改记录，保留旅行记忆和互动创意。
- FILE-MANIFEST.json：逐文件大小和 SHA-256，用于检查传输完整性。

这是纯静态网站，没有后台服务、数据库、API key 或必需环境变量，无需 npm install 或编译。不要通过双击 file://index.html 预览；ES modules 和资源加载应通过 HTTP/HTTPS。

## 部署设置

使用任意支持静态文件的主机，网站根目录设置为 dist。若主机要求上传网站根内容，请上传 dist 内的全部内容（包括 vendor、assets、previews 子目录），确保首页是 index.html。保留文件名大小写和目录结构。服务器必须以 JavaScript MIME 类型返回 .mjs 和 .js，以 application/json 返回 .json，以正确图像 MIME 类型返回 .webp/.jpg/.png。

路由使用 #map、#kaifeng、#xian、#luoyang、#datong、#tokyo、#hongkong，不需要后端路由。不要把请求到的 .mjs 或纹理文件错误重写成 index.html。原站的 ChatGPT 私有访问控制不随 ZIP 迁移；目标网站的访问权限请按用户选择配置。

## 保留的功能

六座真实 3D 微缩城市；鼠标旋转、缩放；地图点击进入单城、返回地图；城市 tile 移动/旋转和动态列车轨道；四季、白天/黄昏/夜晚；音乐、英文、城市列表；各城原有动画互动；底部工具栏和手机适配。

本包已包含最新香港两岸天际线、维港水面与天星小轮、四季细节和天空/窗灯修订。已有性能优化应保留：批量/实例化渲染、资源复用、受限反射分辨率和更新频率。当前六城已检查，不应承诺二十城在所有设备上同样流畅；增加城市后需要重新测量。

## 数据和外部页面

用户布局、季节等偏好保存在浏览器 localStorage，不是 ZIP 中的用户数据；新域名不会自动继承旧域名偏好。站内旅行手账链接指向既有外部站点 https://didiflute.github.io/travel/，本 ZIP 不包含该独立手账网站；请保留现有链接。

## 发布后快速核对

1. 首页地图六座城市与列车正常显示，无缺失模型、纹理或模块请求。
2. 进入香港、开封等城市，旋转后能正常返回地图；动画可开始/结束。
3. 移动城市后列车路径跟随；刷新后保存的布局可恢复。
4. 四季、日/暮/夜切换有明显变化；香港小轮在开阔水面航行。
5. 手机宽度约 390px 时，底部工具栏可操作，不出现横向溢出。

Three.js 许可已保留在 dist/vendor/LICENSE-three.txt；模型相关说明保留在 dist/assets 下。

## 2026-10-17 Claude 修改（在本包基础上）

- 音乐换回原总览用过的五首录音（dist/music/，春《四季》四月、夏《艺人》、秋《四季》十月、冬 Jingle Bells、夜《月光》），跟随季节和昼夜自动选曲；点「音乐」打开面板，含 CC 署名。替换掉合成八音盒。
- 恢复「右边第二颗星」：黄昏/夜晚地图右上角最亮的星，点击后小仙子从星星飞过每座城，撒仙尘，最后金色仙尘落满全城、飞回星星。
- 页眉中文模式显示「温蒂的无何有之乡」；六座城都有手账链接（香港 hk-2025/），同页打开。
- 去掉重复的提示文字（只留工具栏上方一行，按地图/城市/编辑状态变化）；城市名牌缩小、半透明。
- 新增文件：dist/world-music.mjs、dist/second-star.mjs、dist/music/*.mp3。serve.mjs 增加 .mp3/.json/.jpg 的 MIME。部署时服务器需以 audio/mpeg 返回 .mp3。

## 当前线上部署方式（2026-10-17）

- 线上地址：https://didiflute.github.io/travel/ （仓库 didiflute/travel，GitHub Pages）。
- 仓库里 dist/ 的全部内容放在 `neverland/` 文件夹；仓库根目录的 `index.html` 就是 deploy/travel-root-index.html：和 dist/index.html 一样，只是 style.css、importmap 里的 three、main.mjs 三个路径指向 `./neverland/`。所以首页直接显示这个网站，/travel/neverland/ 也能打开。
- 为了支持这种放法，cities.mjs、datong.mjs、longmen.mjs、world-music.mjs 里的图片/模型/音乐路径用 `new URL('./…', import.meta.url).href`（相对模块文件，而不是相对页面）。新增资源请沿用这个写法，否则从首页打开时会 404。
- 改动后交回：整个 dist/ 覆盖仓库的 neverland/；若改了 dist/index.html 的 head 或脚本入口，也要同步更新根目录 index.html（三个 ./neverland/ 路径）。
- 原先的旧总览保存在仓库根目录 old-overview.html，不属于本包。
