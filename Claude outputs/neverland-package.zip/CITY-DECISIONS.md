# 最新城市设计决定（优先于旧原型）

## 2026-10-16 晚间洛阳修订：优先于下文牡丹方案

用户否定首版的粗糙模型，要求真实可辨识的精细 3D 微缩场景：佛像不能是一坨，龙门不能是几块球状岩石，国际佛殿必须有建筑细节。取消牡丹盛开互动，改成「乘车看夜色」：约 8 秒，在伊河对岸的低视角缓慢移动，看灯光下的卢舍那大佛、群像、长阶与金色倒影，结束停留，不自动跳回。国际佛殿群在全景保留，夜游时隐藏，让镜头专注龙门。重置视角恢复全景，返回地图保持布局。

已实际读取用户照片：C:/Users/zwd89/Downloads/537560455_733693572828457_2910394938280453776_n.jpg。照片为正面纵向构图，大佛雕刻于整面崖壁；冷暗山体，暖色集中于佛像和中央阶梯；下方有游客、柳树和河面倒影。照片只作造型与灯光参考，不作为平面背景替代 3D。

2026-10-16，用户重新提供并明确了以下方向。新增城市前先读本文件，不要退回旧版默认地标。

- 西安：大雁塔＋兵马俑，塔高俑低，前景是揭开的考古切面；敲钟与城墙散步保留。
- 洛阳：龙门石窟＋白马寺国际佛殿群。用户明确改成不止一座，包含泰国、印度、缅甸建筑。石窟后侧为主体，佛殿在较低的另一侧，水面、树木、小径隔开。是旅行记忆拼景，并非两个景区实际相邻。
- 洛阳互动：保留牡丹盛开，用户希望更精致、更 fancy，并且要与城市有关。实现为植根水岸花园的牡丹依次绽放，地标始终同框，约 7 秒，结束后保持盛开。牡丹不是替代佛殿的主地标，也不是全屏悬浮花瓣特效。
- 开封：虹桥、桥下行船、桥头集市；沿桥与街形成热闹带，外侧河面留白；360 度铁花保留。
- 大同：云冈石窟在低而宽的一侧，悬空寺在高而窄的崖壁，保留其下深谷。
- 东京：浅草寺雷门与五重塔为主；昭和街巷是整体气氛；东京站红砖圆顶在后侧。
- 香港：九龙城寨密集肌理位于一角，开阔维港水面与绿白天星小轮为对比。

所有城市共享同一个真实 3D 世界。地图上的 tile 可拖动、交换、90 度旋转，火车自动改轨。点击城市进入仅显示该城的全屏细节，可 360 度旋转；返回地图恢复布局与镜头。保留原有布局，加入新城市时迁移数据，不清空用户排列。

性能：一个 WebGLRenderer，30 fps 与像素上限；非选中城市不运行动画；静态几何按材质合并，牡丹花瓣四组实例化共享几何。只验证当前三座城市，不宣称 20 城已经通过性能测试。

参考：https://www.lmsk.cn/Gywm_id_5.html （龙门官方：奉先寺九身造像）；https://www.eeo.com.cn/2024/0207/635656.shtml （白马寺印度、泰国与缅甸苑）。

验证：node check-luoyang.mjs 检查旧布局迁移、三城地图、全屏进入返回、花开结束、城市切换后 GPU 资源稳定、手机宽度与控制按钮。


## 2026-10-16 21:28 PDT - 2.5D trial rejected and reverted

The user rejected the flat illustrated tile among the other three-dimensional cities and requested restoration of the entire pre-2D version. Restore deployment source 7210dfb3abc96ab97fec3a7b4e92ad9696705aeb. Do not treat the earlier 2.5D experiment as the approved direction. This rollback does not mean the earlier Buddha model has been approved.

## 2026-10-16 - Refine the restored 3D Luoyang scene

The user requested a dignified monumental Buddha, recognizable temple architecture and softly trailing willow foliage. Keep the rotatable three-dimensional map and city detail scene.

- Replace primitive figures with closed sculptural volumes, shaped front surfaces and detailed stone imagery. This is an illustrative miniature, not a scan. Front detail is stronger than side and rear detail.
- Make the central Buddha the lighting focus. Four smaller attendants stay dimmer. Use a recessed limestone cliff, a halo and a lit stairway to establish scale.
- Retain the White Horse Temple international temple group: Thai colonnade and layered roofs, Indian stupa and torana, Myanmar bell stupa, plus a small Chinese entrance gate.
- Replace wire-like foliage with narrow 3D willow leaves in hanging clusters. Wind uses a vertex shader rather than per-leaf JavaScript updates.
- Preserve the existing eight-second river-view interaction and movable tiles/train routing. The ride remains a cinematic camera treatment; a fully modeled passenger shuttle is not implemented in this revision.
- Use shared attendant geometry/textures and compressed WebP assets. Desktop/mobile route checks, rotation, map return and repeated city switching pass without browser errors; warmed GPU geometry and texture counts stay stable. This does not establish performance for twenty cities or all devices.

## 2026-10-16 21:58 PDT - Light, visitors, water and an actual shuttle

The user accepted the model direction and requested four concrete corrections. Use the supplied night photograph for a broad warm wash across the cliff and calmer overhead light on the attendants, rather than isolated upward face lighting. Add small groups of visitors, visible people on the platform and people climbing the stairs. Replace the schematic water pattern with a real scene reflection, broken by subtle water distortion.

The eight-second interaction now moves a modeled open electric shuttle with canopy, seats, four passengers and rotating wheels from left to right on the near-bank road. The camera settles into a fixed river view rather than orbiting as a substitute for the vehicle. Replay resets the shuttle; stop freezes its position. The entire scene remains rotatable outside the short interaction.

Water reflection uses a single 384px target, updates at most eight times a second while Luoyang is open, and stops updating on the map or in other cities. Geometry and textures are reused on replay and city switches.

## 2026-10-16 22:06 PDT - Many small lights and a light breeze

Keep the accepted scene, people, river and shuttle. Following the user's photograph, emphasize many small warm fixtures: three stair lanes, platform edges, the lower terrace and a winding cliff-top string. Reduce the dominant broad light slightly. Lamp halos are a single batched mesh with no added point lights or shadow maps.

Willow strands now have independent phases and stronger motion toward their hanging tips. The crown stays almost still. Leaf geometry is reused and displaced in the vertex shader; the existing reduced-motion preference continues to disable ambient movement.

## 2026-10-16 - Datong: Yungang and the Hanging Temple

Continue the user's agreed six-city composition. Datong combines the lower, wider exposed Yungang Buddha with a higher Hanging Temple, linked by sandstone cliffs and separated from the foreground by open valley space. Use soft daylight to distinguish it from Luoyang's night scene. These are composed landmarks, not a geographically accurate reconstruction.

The Cave 20-inspired Buddha uses an illustrated closed sculptural volume, not a scan; detail is strongest from the front. The temple has yellow tiled roofs with green borders, red columns, recessed window screens, open galleries, two three-storey towers, stair connections, cantilever beams and slender timber poles. Preserve the void below it. The seven-second optional interaction follows three visitors across the gallery and up the connecting stair. It is an illustrative activity, not a claimed travel memory.

Datong joins the existing editable 3D map. Migrate saved two- and three-city layouts without moving or rotating the existing tiles; place missing tiles in the nearest free cell. Keep the single renderer and shared lighting. Static architecture is batched by material; new compressed sculpture assets total about 607 KB. Only three people move during the interaction. This does not certify performance at twenty cities: future expansion still needs lazy loading and distance-based detail.

References: Hengshan Scenic Area Management Center, https://www.byhs.net.cn/culture_detial/77.html ; Cave 20 photograph by xiquinhosilva, via Smarthistory, https://smarthistory.org/wp-content/uploads/2020/11/Buddha-20-scaled.jpg (CC BY 2.0). Asset attribution and modeling limitations are recorded in dist/assets/datong/README.md.

## 2026-10-16 22:32 PDT - Correct Hanging Temple supports and approach

User correction: the temple must read as suspended midway up the cliff. Shorten all visible vertical poles so their feet stop on small mid-cliff rock ledges, emphasize the horizontal cantilever beams entering the mountain, and leave the valley below clear. Remove the entire invented left-hand ground-to-temple switchback staircase, including rails and landings. Retain the high connecting stair between the two towers and its existing visitor interaction.

## 2026-10-16 - Tokyo: Asakusa, Showa streets, Tokyo Station and hanabi

User: continue Tokyo, keeping a recognizable fireworks-festival interaction. Follow the previously agreed composition: Kaminarimon's red lantern and Senso-ji's five-storey pagoda are the primary landmarks, a short Showa-style shopping street provides atmosphere, and Tokyo Station's brick facade and two domes form the background. This is a composed travel-memory tile, not a claim that the station is beside Senso-ji. Retain true 3D, full-screen city entry, rotation, return to map, movable tiles and train rerouting.

The nine-second optional performance includes five bounded spherical shells: trailing chrysanthemum, colored peony with inner cores, and a descending gold crown finale. Include launch trails, a brief delay before bursting, air drag, gravity, fading sparks and restrained drifting smoke. Stars occupy a real 3D sphere. The camera reframes to include the sky. River glints respond to firework color, using a lightweight procedural approximation rather than another reflection render target. Finish and stop hide the performance; replay reuses the same arrays. Four people stroll only while Tokyo is open; the rest are small static groups. Reduced-motion stops ambient movement and softens the clicked fireworks.

Architecture uses modeled curved gray roof surfaces, fine tile seams, red timber and pale rafter ends, a pleated large lantern, recessed shop windows, striped awnings, small signs, planters, bicycles, stone banks and lamps. The station has pale stone bands, brickwork, mansard roofs, an arched central clock pediment and ribbed domes. Generic signs share one small canvas atlas. No photographic building planes, downloaded imagery, extra renderer or shadow maps were added. Fireworks use at most 1,450 stars on desktop and 950 on a fresh narrow-screen load, plus pooled trail buffers. This bounded change is not a twenty-city performance guarantee; later scaling still requires loading/detail limits.

References inspected: Senso-ji official Kaminarimon https://www.senso-ji.jp/guide/guide01.html and pagoda https://www.senso-ji.jp/guide/guide06.html ; Tokyo Convention & Visitors Bureau https://www.gotokyo.org/en/story/walks-and-tours/tokyo-station-and-marunouchi/index.html ; Sumida River Fireworks Festival FAQ https://www2.sumidagawa-hanabi.com/faq/index.html ; Japan Pyrotechnics Association fireworks guide https://www.hanabi-jpa.jp/booklet2026/pageindices/index15.html . Reference photographs are not shipped with the site.

## 2026-10-17 - Hong Kong: dense city, open harbour and Star Ferry

Continue the user's agreed sixth city: a compact historic Kowloon Walled City, generous Victoria Harbour water and a green/white double-ended Star Ferry. This is an artistic memory composition, not a geographically accurate waterfront reconstruction or a claim that the demolished city still exists. Preserve all five existing destinations and the editable, rotatable map with train rerouting. Saved five-city layouts migrate without changing their existing positions or rotations.

Nineteen adjoining buildings surround a small courtyard. Model recessed window frames, partial balcony cages, window air conditioners, exposed plumbing, hanging cables, repairs, corrugated rooftop additions, water tanks, antennas, laundry, market awnings and small traditional-character shop signs. Add a modest ferry pier, quay visitors, benches and trees. All structures and ferry geometry are genuine 3D; no photographic planes are used. Procedural plaster patina and one shared sign atlas keep assets small. Reference photos are not redistributed.

The optional eight-second interaction reframes toward the harbour and moves the ferry across a gently curving route. It includes open lower seating, upper windows, portholes, two wheelhouses, funnel, masts, life rings, tire bumpers and a few passengers. Replays reuse fixed wake buffers. Ambient bobbing and water motion respect reduced motion. Moving ferry meshes do not cast into the static cached shadow map. A single 320-pixel reflection target captures at most six times per second, only while Hong Kong is open; map view skips these captures. Architecture is batched once by material and uses the existing renderer and lights. This is not a twenty-city performance guarantee; future expansion still needs lazy loading and distance-dependent geometry.

References inspected: M+ historical photographs and Ian Lambot's aerial view, https://www.mplus.org.hk/en/magazine/exploring-kowloon-walled-city-photographic-journey/ ; Star Ferry official real-vessel photographs and pier information, https://www.starferry.com.hk/ and https://www.starferry.com.hk/en/pier ; Hong Kong Tourism Board, https://www.discoverhongkong.com/eng/place-to-go/travel.guide-star-ferry-pier.html .

## 2026-10-17 - Restore the original world controls from the user's screenshot

The user's local reference `C:\Users\zwd89\Downloads\date` is a PNG of the original pale rounded toolbar. It explicitly shows overview, edit cities, spring/summer/autumn/winter, day/dusk/night, music, EN, and list, with an instruction above for dragging to rotate, scrolling to zoom, and clicking a city to enter. Restore these functional controls around the existing six-city 3D world. Preserve city models, click performances, full-screen entry/return, editable tile positions/rotations, saved layouts and train rerouting.

Use a pale translucent segmented toolbar with outlined icons and white active chips. It wraps into two rows on a phone. The city drawer contains all six city names and landmark subtitles, can enter a city or select a tile while editing, and closes by close button, outside click or Escape. English translates navigation, map labels, city descriptions, performance actions and layout controls; historic signs inside models stay in their original languages. Season, time and language preferences persist locally. Autumn/dusk are the reference defaults.

Seasons tint explicitly tagged vegetation materials, leaving architecture alone. Winter uses a shared procedural snow buffer with 90 points per tile; reduced motion holds it still. Time settings reuse the scene's existing lights, background and emissive materials. Kaifeng iron flowers, Tokyo fireworks and Luoyang's evening ride temporarily use night lighting and restore the chosen time afterward. Scroll zoom is bounded to 0.6–2.6, has plus/minus keyboard equivalents and resets on overview or city entry; map zoom is restored when returning from a visit.

Music starts only on explicit click: an original sixteen-second synthesized music-box phrase with one 1,411,200-byte mono buffer, reused on subsequent toggles. It suspends when the page is hidden and does not autoplay on reload. No external audio or image asset downloads, second renderer, additional shadow maps or postprocessing passes are added. Toolbar browser checks cover all settings, language switching, music start/stop/reuse, drawer navigation, zoom/reset, layout rerouting, nighttime interaction restoration, mobile fit, preference persistence and stable geometry/texture counts after repeated setting changes.

## 2026-10-17 - Make Hong Kong recognisable; strengthen seasons, daylight, sunset and city lights

User feedback: the ferry and water alone do not convey Victoria Harbour; seasonal changes are too small, daylight is gray-green, dusk is purple, night feels deserted, and the toolbar blocks the scene. Recompose Hong Kong into two shores. Keep the detailed historic Walled City as a smaller near-bank quarter, add a wide central channel, and build a recognisable Hong Kong Island skyline on the far bank. Include Two IFC's tapered silver crown, the Bank of China Tower's stepped triangular volumes and diagonal bracing, an HSBC-inspired structural waterfront block, the Convention Centre's curved roof, and a modest near-bank Clock Tower. This remains an explicitly composed memory tile, not an accurate historical or geographical reconstruction. The ferry starts in clear water and follows a curved route between the banks. Roofs and hill materials are kept distinct from seasonally coloured deciduous trees.

Daylight now uses a clear blue-to-pale-blue sky, neutral bright fill and higher sun. Dusk uses an amber/peach sky, visible low sun glow, warm low-angle lighting and broken warm water reflections. Night has warmer varied windows, continuous small quay lamps and bounded halos on existing lit features across all six cities. Hong Kong's window selection is substantially denser. All windows and lamp halos share materials or fixed point buffers, with no per-window point lights or added shadow maps. Harbour reflections retain the existing 320px throttled target and pause in map view.

Spring now has bounded instanced blossom clusters on sampled tree surfaces, summer has deeper green foliage, autumn has stronger gold-orange crowns and scattered leaves, and winter coats upward-facing selected roofs, stairs, stone and paving with procedural snow, alongside the existing snowfall. The shared snow uniform changes the existing material shaders; it does not create new materials on each switch. Blossom, fallen-leaf and lamp buffers are created once. Seasonal settings are an artistic world treatment, not a claim about normal Hong Kong snowfall. The entire original toolbar moves to the bottom on desktop, mobile and landscape, with the city list and interaction panel repositioned above it.

Visual checks cover the three Hong Kong light settings, ferry visibility/motion, all four seasons in the full map, and mobile controls without overlap. Repeated settings changes retain the same geometry and texture counts. The original map editing, train route, zoom and bilingual controls remain. New skyline geometry is batched and the sky uses one reusable 512px canvas texture.

References: Hong Kong Tourism Board's Two IFC, https://www.discoverhongkong.com/eng/place-to-go/travel.guide-two-international-finance-centre.html ; Bank of China Tower, https://www.discoverhongkong.com/eng/place-to-go/travel.guide-bank-of-china-tower.html ; harbourfront, ferry and Convention Centre, https://www.discoverhongkong.com/eng/attractions/scenic-victoria-harbour-walk.html . No external photos or audio are bundled.

## 2026-10-17 (Claude) - Original music restored; the second star returns; small fixes

User request: replace the synthesized music-box phrase with the five recordings the original overview used, and bring back the "brightest star in the night sky" idea.

- Music (`world-music.mjs`, files in `dist/music/`, ~13.7 MB, 112 kbps MP3, loudness-normalised): spring = Tchaikovsky *The Seasons* April; summer = Joplin *The Entertainer*; autumn = *The Seasons* October; winter = *Jingle Bells (Calm)*; night = Debussy *Clair de lune*. Default "follow season & time": night (non-winter) plays Clair de lune, winter always Jingle Bells, otherwise the season's piece. It follows the toolbar's chosen time, not a performance's temporary night. The toolbar 音乐 button opens a small panel (play/pause, auto + five tracks, required CC credits). Nothing autoplays; tracks cross-fade through Web Audio gain nodes (iOS ignores element volume); a track file loads only when first played; audio pauses when the page is hidden. The user's earlier picks (Merry Christmas Mr. Lawrence, Kikujiro "Summer") are copyrighted and stay out of the public site.
- The second star (`second-star.mjs`): the brightest star sits in the upper-right sky of the map at dusk (fainter) and night; hidden in day, in city detail, while editing and during performances. Hover/focus (and once, the first time it appears) shows 「右边第二颗星，一直飞到天亮。」 / "Second to the right, and straight on till morning." Clicking it sends a small fairy light from the star over every visible city tile (nearest-neighbour route), trailing fairy dust; a golden shower then settles over the map and she flies back into the star, which flashes. One sprite + one 1,400-point buffer, created once, reused, idle when not playing; entering a city or editing cancels it. Reduced motion: star flash + message only.
- Header shows the chosen Chinese name 「温蒂的无何有之乡」 with WENDY'S NEVERLAND underneath in Chinese mode; English mode keeps "Wendy's Neverland".
- Journal link now appears for all six cities with the real folders (hk-2025/ for Hong Kong; datong/tokyo/hongkong were previously hidden) and opens in the same tab so Back returns to the city.
- Phones: the map fills more of the screen width.
- Follow-up (same day): one hint line only — the line above the toolbar is now contextual (map / inside a city / editing) and the duplicate footer hint is hidden. City labels are smaller and more translucent (brighter on hover or when selected) so they cover less of the models.
